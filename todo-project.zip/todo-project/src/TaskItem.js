function TaskItem({ task, toggleTask, deleteTask }) {
  return (
    <div
      className={`task-item ${task.completed ? "completed" : ""}`}
      style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
    >
      <span
        onClick={() => toggleTask(task.id)}
        style={{ cursor: "pointer", flex: 1 }}
      >
        {task.text}
      </span>

      <button onClick={() => deleteTask(task.id)}>❌</button>
    </div>
  );
}

export default TaskItem;
